// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApp
{
public:
	CLcSprite*		m_pLcSprite;
	CLcInput*		m_pInput;

	
	CLcTexture*		m_pTexBack;
	
	CLcTexture*			m_pTexAni;
	LPDIRECT3DTEXTURE9	m_pTexAniS;			// �׸��� �ؽ�ó

	DWORD			m_dTimeBgn;			// ���� Ÿ��
	DWORD			m_dTimeEnd;			// �� Ÿ��
	RECT			m_ImgRc1;			// RECT �ִ� �̹���

public:
	CMain();

	virtual INT		Init();
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual INT		Render();

	virtual LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);
};


extern CMain*	g_pApp;

#endif